package enigma.livecodesmartclass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiveCodeSmartClassApplicationTests {

	@Test
	void contextLoads() {
	}

}
