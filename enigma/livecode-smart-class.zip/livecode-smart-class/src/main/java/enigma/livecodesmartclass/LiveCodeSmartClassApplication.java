package enigma.livecodesmartclass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiveCodeSmartClassApplication {

	public static void main(String[] args) {
		SpringApplication.run(LiveCodeSmartClassApplication.class, args);
	}

}
