package com.red.team.taskvisionapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskVisionApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskVisionApplication.class, args);
	}

}
