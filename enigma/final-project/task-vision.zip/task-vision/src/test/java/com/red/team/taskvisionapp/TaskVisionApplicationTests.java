package com.red.team.taskvisionapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskVisionApplicationTests {

	@Test
	void contextLoads() {
	}

}
